// When the "Change the Heading" button is clicked...
document.getElementById("changeTextBtn").addEventListener("click", function () {
    // Change the text of the heading
    const heading = document.getElementById("mainHeading");
    heading.textContent = "You clicked the button!";
    heading.style.color = "red"; // change the color
    heading.style.fontSize = "40px"; // make it bigger
  });
  
  // When the "Add/Remove the Box" button is clicked...
  document.getElementById("toggleBoxBtn").addEventListener("click", function () {
    const container = document.getElementById("boxContainer");
    const existingBox = document.getElementById("colorBox");
  
    // If the box is already there, remove it
    if (existingBox) {
      existingBox.remove();
    } else {
      // Otherwise, create a new box and add it
      const newBox = document.createElement("div");
      newBox.id = "colorBox";
      newBox.style.width = "150px";
      newBox.style.height = "150px";
      newBox.style.backgroundColor = "blue";
      newBox.style.margin = "20px auto";
      container.appendChild(newBox);
    }
  });
  